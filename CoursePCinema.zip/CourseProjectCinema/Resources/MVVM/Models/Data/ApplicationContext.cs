﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfAppCinema.Resources.MVVM.Models.Data
{
    public class ApplicationContext : DbContext
    {
        public DbSet<Film> films { get; set; }
        public DbSet<Hall> halls { get; set; }
        public DbSet<Session> sessions { get; set; }
        public DbSet<Ticket> tickets { get; set; }

        public ApplicationContext() => Database.EnsureCreated();
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {

            optionsBuilder.UseSqlServer(@"Data Source=MSI-AEGIS-TI3;Initial Catalog=WPFCinema9;Integrated Security=True");
        }
    }
}
