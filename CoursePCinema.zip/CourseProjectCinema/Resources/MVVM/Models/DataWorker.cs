﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfAppCinema.Resources.MVVM.Models.Data;

namespace WpfAppCinema.Resources.MVVM.Models
{
    public class DataWorker
    {

        #region
        public static List<Film> GetAllFilms()
        {
            using (ApplicationContext db = new ApplicationContext())
            {
                var result = db.films.ToList();
                return result;
            }
        }
        //public static List<Session> GetAllFilmsById()
        //{
        //    using (ApplicationContext db = new ApplicationContext())
        //    {
        //        List<Session> cp = (from Session in GetAllSessions() where   select Session).ToList();
        //        return cp;
        //    }
        //}

        public static List<Session> GetAllSessionByFilmId(int id)
        {
            using (ApplicationContext db = new ApplicationContext())
            {
                List<Session> students = (from Session in GetAllSessions() where Session.filmid == id select Session).ToList();
                return students;
            }
        }

        public static List<Hall> GetAllHalls()
        {
            using (ApplicationContext db = new ApplicationContext())
            {
                var result = db.halls.ToList();
                return result;
            }
        }
        public static List<Hall> GetAllHallsById(int id)
        {
            using (ApplicationContext db = new ApplicationContext())
            {
                List<Hall> cp = (from Hall in GetAllHalls() where Hall.id == id select Hall).ToList();
                return cp;
            }
        }


        public static List<Session> GetAllSessions()
        {
            using (ApplicationContext db = new ApplicationContext())
            {
                var result = db.sessions.ToList();
                return result;
            }
        }
        public static List<Session> GetAllSessionsById(int id)
        {
            using (ApplicationContext db = new ApplicationContext())
            {
                List<Session> cp = (from Session in GetAllSessions() where Session.id == id select Session).ToList();
                return cp;
            }
        }


        public static List<Ticket> GetAllTickets()
        {
            using (ApplicationContext db = new ApplicationContext())
            {
                var result = db.tickets.ToList();
                return result;
            }

        }
        public static List<Ticket> GetAllTicketsById(int id)
        {
            using (ApplicationContext db = new ApplicationContext())
            {
                List<Ticket> cp = (from Ticket in GetAllTickets() where Ticket.id == id select Ticket).ToList();
                return cp;
            }
        }
        #endregion

        #region
        public static Film GetFilmById(int id)
        {
            using (ApplicationContext db = new ApplicationContext())
            {
                Film pos = db.films.FirstOrDefault(p => p.id == id);
                return pos;
            }
        }

        public static Hall GetHallById(int id)
        {
            using (ApplicationContext db = new ApplicationContext())
            {
                Hall pos = db.halls.FirstOrDefault(p => p.id == id);
                return pos;
            }
        }

        public static Session GetSessionById(int id)
        {
            using (ApplicationContext db = new ApplicationContext())
            {
                Session pos = db.sessions.FirstOrDefault(p => p.id == id);
                return pos;
            }
        }

        public static Ticket GetTicketById(int id)
        {
            using (ApplicationContext db = new ApplicationContext())
            {
                Ticket pos = db.tickets.FirstOrDefault(p => p.id == id);
                return pos;
            }
        }
        #endregion

        public static string CreateFilm(string FilmName, Hall hall)
        {
            string result = "Уже существует";
            using (ApplicationContext db = new ApplicationContext())
            {
                //проверяем сущесвует ли студент
                bool checkIsExist = db.films.Any(el => el.filmName == FilmName);
                if (!checkIsExist)
                {
                    Film newFilms = new Film
                    {
                        filmName = FilmName,
                        hallid = hall.id
                    };
                    db.films.Add(newFilms);
                    db.SaveChanges();
                    result = "Студент добавлен!";
                }
                return result;
            }
        }
        public static string CreateHall(string HallName)
        {
            string result = "Уже существует";
            using (ApplicationContext db = new ApplicationContext())
            {
                //проверяем сущесвует ли студент
                bool checkIsExist = db.halls.Any(el => el.choiceHall == HallName);
                if (!checkIsExist)
                {
                    Hall newHalls = new Hall
                    {
                        choiceHall = HallName
                       
                    };
                    db.halls.Add(newHalls);
                    db.SaveChanges();
                    result = "Студент добавлен!";
                }
                return result;
            }
        }

        public static string CreateSession(Film Name,int price,string date)
        {
            string result = "Уже существует";
            using (ApplicationContext db = new ApplicationContext())
            {
                //проверяем сущесвует ли студент
                bool checkIsExist = db.sessions.Any(el => el.price == price);
                if (!checkIsExist)
                {
                    Session newSession = new Session
                    {
                        filmid = Name.id,
                        price = price,  
                        Date = date

                    };
                    db.sessions.Add(newSession);
                    db.SaveChanges();
                    result = "Студент добавлен!";
                }
                return result;
            }
        }

        //public static string CreateTiket(Film Name,Session date, Hall hall,int row,int mesto)
        //{
        //    string result = "Уже существует";
        //    using (ApplicationContext db = new ApplicationContext())
        //    {
        //        //проверяем сущесвует ли студент
        //        bool checkIsExist = db.tickets.Any(el => el.amountRows == row);
        //        if (!checkIsExist)
        //        {
        //            Ticket newtickets = new Ticket
        //            {
        //                sessionDate = Name.id,
        //                amountPlace = mesto,
        //                amountRows= row,
        //                sessionDate =

        //            };
        //            db.tickets.Add(newtickets);
        //            db.SaveChanges();
        //            result = "Студент добавлен!";
        //        }
        //        return result;
        //    }
        //}



        public static string DeleteFilm(Film Films)
        {
            string result = "Такой Film не существует";
            using (ApplicationContext db = new ApplicationContext())
            {

                db.films.Remove(Films);
                db.SaveChanges();
                result = "Сделано! " + Films.filmName + " Удалена";
            }
            return result;
        }

        public static string DeleteHall(Hall Halls)
        {
            string result = "Такой Film не существует";
            using (ApplicationContext db = new ApplicationContext())
            {

                db.halls.Remove(Halls);
                db.SaveChanges();
                result = "Сделано! " + Halls.choiceHall + " Удалена";
            }
            return result;
        }

        public static string DeleteSession(Session Sessions)
        {
            string result = "Такой Film не существует";
            using (ApplicationContext db = new ApplicationContext())
            {

                db.sessions.Remove(Sessions);
                db.SaveChanges();
                result = "Сделано! " + Sessions.price + " Удалена";
            }
            return result;
        }

        

public static string DeleteTicket(Ticket Tickets)
        {
            string result = "Такой Film не существует";
            using (ApplicationContext db = new ApplicationContext())
            {

                db.tickets.Remove(Tickets);
                db.SaveChanges();
                result = "Сделано! " + Tickets.amountPlace + Tickets.amountRows + " Удалена";
            }
            return result;
        }

        public static string EditFilm(Film oldFilm, string FilmName, Hall hall)
        {
            string result = "Такого Резервирование не существует";
            using (ApplicationContext db = new ApplicationContext())
            {
                Film film = db.films.FirstOrDefault(d => d.id == oldFilm.id);
                film.filmName = FilmName;
                film.hallid = hall.id;

                db.SaveChanges();
                result = "Сделано! filmName " + film.filmName + " изменено";
            }
            return result;
        }

        public static string EditHall(Hall oldHall, string hall)
        {
            string result = "Такого Резервирование не существует";
            using (ApplicationContext db = new ApplicationContext())
            {
                Hall halls = db.halls.FirstOrDefault(d => d.id == oldHall.id);
                halls.choiceHall = hall;
           

                db.SaveChanges();
                result = "Сделано! choiceHall " + halls.choiceHall + " изменено";
            }
            return result;
        }



        public static string EditSession(Session oldSession, Film FilmNAME, int price,  string date)
        {
            string result = "Такого Резервирование не существует";
            using (ApplicationContext db = new ApplicationContext())
            {
                Session session = db.sessions.FirstOrDefault(d => d.id == oldSession.id);
                session.filmid = FilmNAME.id;
                session.price = price;      
                session.Date = date;


                db.SaveChanges();
                result = "Сделано! choiceHall " + session.price + " изменено";
            }
            return result;
        }
         /// возможно не правильно 
        public static string EditTicket(Ticket oldTicket, Film name,Session date,Hall hall, int row , int place)
        {
            string result = "Такого Резервирование не существует";
            using (ApplicationContext db = new ApplicationContext())
            {
                Ticket ticket = db.tickets.FirstOrDefault(d => d.id == oldTicket.id);
                ticket.session.filmid = name.id;
                ticket.session.Date = date.Date;
                ticket.session.filmid = hall.id;
                ticket.amountRows = row;
                ticket.amountPlace = place;
                


                db.SaveChanges();
                result = "Сделано! choiceHall " + ticket.amountRows + " изменено";
            }
            return result;
        }




    }

    



}
