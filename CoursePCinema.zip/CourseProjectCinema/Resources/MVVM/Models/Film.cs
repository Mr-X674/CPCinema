﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfAppCinema.Resources.MVVM.Models
{
    public class Film
    {
        [Key]
        public int id { get; set; }

        [Required]
        public string filmName { get; set; }

        [Required]
        public int? hallid { get; set; }

        [ForeignKey("hallid")]
        public Hall hall { get; set; }

        [NotMapped]
        public Hall Hall
        {
            get
            {
                return DataWorker.GetHallById((int)hallid);
            }
        }
    }
}
