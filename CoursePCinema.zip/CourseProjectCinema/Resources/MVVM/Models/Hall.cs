﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfAppCinema.Resources.MVVM.Models
{
       public class Hall
    {
        [Key]
        public int id { get; set; }

        [Required]
        public string choiceHall { get; set; }

    }
}
