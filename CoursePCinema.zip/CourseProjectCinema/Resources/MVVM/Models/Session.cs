﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfAppCinema.Resources.MVVM.Models
{
    public class Session
    {
        [Key]
        public int id { get; set; }

        [Required]
        public int price { get; set; }

        [Required]
        public string Date { get; set; }

        [Required]
        public int? filmid { get; set; }

        [ForeignKey("filmid")]
        public Film filmname { get; set; }

        [NotMapped]
        public Film Filmname
        {
            get
            {
                return DataWorker.GetFilmById((int)filmid);
            }
        }
    }
}
