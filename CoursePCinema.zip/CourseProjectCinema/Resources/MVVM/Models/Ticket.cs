﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfAppCinema.Resources.MVVM.Models
{
    public class Ticket
    {
        [Key]
        public int id { get; set; }

       

        [Required]
        public int? sessionDate { get; set; }

        [ForeignKey("sessionDate")]
        public Session session { get; set; }

        [Required]
        public int amountRows { get; set; }

        [Required]
        public int amountPlace { get; set; }



        public Session Session
        {
            get
            {
                return DataWorker.GetSessionById((int)sessionDate);
            }
        }


    }
}
