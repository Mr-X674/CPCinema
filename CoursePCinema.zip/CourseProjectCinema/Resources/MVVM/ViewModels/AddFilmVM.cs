﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using WpfAppCinema.Resources.MVVM.Models;

namespace WpfAppCinema.Resources.MVVM.ViewModels
{
    public class AddFilmVM : DataManageVM
    {

        #region COMMANDS TO ADD
        private RelayCommand addNewFilms;
        public RelayCommand AddNewFilms
        {
            get
            {
                return addNewFilms ?? new RelayCommand(obj =>
                {
                    Window wnd = obj as Window;
                    string resultStr = "";
                    if (filmName == null )
                    {
                        if (filmName == null || filmName.Replace(" ", "").Length == 0)
                        {
                            SetRedBlockControll(wnd, "TextBoxFilmName");
                        }
                        if (filmHall == null )
                        {
                            SetRedBlockControll(wnd, "ComboBoxHall");
                        }

                    }
                    else
                    {
                        resultStr = DataWorker.CreateFilm(filmName,filmHall);
                        UpdateInfoView();
                        SetNullValuesToProperties();
                        wnd.Close();
                    }
                }
                );
            }
        }
        #endregion
    }
}
