﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using WpfAppCinema.Resources.MVVM.Models;

namespace WpfAppCinema.Resources.MVVM.ViewModels
{
    public class AddHallVM : DataManageVM
    {


        #region COMMANDS TO ADD
        private RelayCommand addNewHall;
        public RelayCommand AddNewHall
        {
            get
            {
                return addNewHall ?? new RelayCommand(obj =>
                {
                    Window wnd = obj as Window;
                    string resultStr = "";
                    if (choiceHall == null)
                    {
                        if (choiceHall == null)
                        {
                            SetRedBlockControll(wnd, "TextHall");
                        }                   
                    }
                    else
                    {
                        resultStr = DataWorker.CreateHall(choiceHall);
                        UpdateInfoView();
                        SetNullValuesToProperties();
                        wnd.Close();
                    }
                }
                );
            }
        }
        #endregion
    }
}
