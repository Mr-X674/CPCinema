﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using WpfAppCinema.Resources.MVVM.Models;

namespace WpfAppCinema.Resources.MVVM.ViewModels
{
    public class AddSessionVM : DataManageVM
    {

        #region COMMANDS TO ADD
        private RelayCommand addNewSession;
        public RelayCommand AddNewSession
        {
            get
            {
                return addNewSession ?? new RelayCommand(obj =>
                {
                    Window wnd = obj as Window;
                    string resultStr = "";
                    if (FilmNAME == null)
                    {
                        if (FilmNAME == null )
                        {
                            SetRedBlockControll(wnd, "ComboBoxFilm");
                        }
                        if (price == 0)
                        {
                            SetRedBlockControll(wnd, "TextBoxPrice");
                        }
                        if (date == null)
                        {
                            SetRedBlockControll(wnd, "TextBoxDate");
                        }

                    }
                    else
                    {
                        resultStr = DataWorker.CreateSession(FilmNAME, price, date);
                        UpdateInfoView();
                        SetNullValuesToProperties();
                        wnd.Close();
                    }
                }
                );
            }
        }
        #endregion



    }
}
