﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using WpfAppCinema.Resources.MVVM.Models;
using WpfAppCinema.Resources.MVVM.Views;

namespace WpfAppCinema.Resources.MVVM.ViewModels
{
    public class DataManageVM : INotifyPropertyChanged
    {

        // свойства для Фильм
        public static Hall filmHall { get; set; }
        public static string filmName { get; set; }

        // свойства для Холла
        public static string choiceHall { get; set; }
        public static int amountRows { get; set; }
        public static int amountPlace { get; set; }

        // свойства Сеансов
        public static Film FilmNAME { get; set; }
        public static int price { get; set; }
        public static string date { get; set; }

        // свойства Билетов 
        public static Film sessionFilm { get; set; }
        public static Session ticketFilm { get; set; }
        public static Session sessionDate { get; set; }
        public static Hall TicketHall { get; set; }



        public TabItem SelectedTabItem { get; set; }
        public static Film SelectedFilm { get; set; }
        public static Hall SelectedHall { get; set; }
        public static Session SelectedSession { get; set; }
        public static Ticket SelectedTicket { get; set; }


        public event PropertyChangedEventHandler PropertyChanged;

        private void NotifyPropertyChanged(String propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }


        private List<Film> allFilms = DataWorker.GetAllFilms();
        public List<Film> AllFilms
        {
            get { return allFilms; }
            set
            {
                allFilms = value;
                NotifyPropertyChanged("AllFilms");
            }
        }
        private List<Session> allSessionByFilmId;
        public List<Session> AllSessionByFilmId
        {
            get { return allSessionByFilmId; }
            set
            {
                AllSessionByFilmId = value;
                NotifyPropertyChanged("allSessionByFilmId");
            }
        }
        //private List<Session> metod = DataWorker.GetAllFilmsById();
        //public List<Session> Metod
        //{
        //    get { return metod; }
        //    set
        //    {
        //        metod = value;
        //        NotifyPropertyChanged("AllSessions");
        //    }
        //}

        private List<Hall> allHalls = DataWorker.GetAllHalls();
        public List<Hall> AllHalls
        {
            get { return allHalls; }
            set
            {

                allHalls = value;
                NotifyPropertyChanged("AllHalls");
            }
        }

        private List<Session> allSession = DataWorker.GetAllSessions();
        public List<Session> AllSession
        {
            get { return allSession; }
            set
            {

                allSession = value;
                NotifyPropertyChanged("AllSessions");
            }
        }


        private List<Ticket> allTicket = DataWorker.GetAllTickets();
        public List<Ticket> AllTickets
        {
            get { return allTicket; }
            set
            {

                allTicket = value;
                NotifyPropertyChanged("AllTickets");
            }
        }
        public static void SetNullValuesToProperties()
        {
            //для фильмов
            filmHall = null;
            filmName = null;

            //для Залов
            choiceHall = null;
            amountRows = 0;
            amountPlace = 0;

            //для Сеансов
            price = 0;
            date = null;

            //для Билетов
            sessionFilm = null;
            ticketFilm = null;
            sessionDate = null;
        }
        protected void UpdateInfoView()
        {
            UpdateFilmsWWInfo();
            UpdateHallEDWInfo();
            UpdateSessionInfo();
            UpdateTicketInfo();
        }
        
        protected void UpdateFilmsWWInfo()
        {
            AllFilms = DataWorker.GetAllFilms();
            MainWork.AllFilmsInfoListView.ItemsSource = null;
            MainWork.AllFilmsInfoListView.Items.Clear();
            MainWork.AllFilmsInfoListView.ItemsSource = AllFilms;
            MainWork.AllFilmsInfoListView.Items.Refresh();
        }
        protected void UpdateHallEDWInfo()
        {
            AllHalls = DataWorker.GetAllHalls();
            MainWork.AllHallsInfoListView.ItemsSource = null;
            MainWork.AllHallsInfoListView.Items.Clear();
            MainWork.AllHallsInfoListView.ItemsSource = AllHalls;
            MainWork.AllHallsInfoListView.Items.Refresh();
        }
        protected void UpdateSessionInfo()
        {
            AllSession = DataWorker.GetAllSessions();
            MainWork.AllSessionsInfoListView.ItemsSource = null;
            MainWork.AllSessionsInfoListView.Items.Clear();
            MainWork.AllSessionsInfoListView.ItemsSource = AllSession;
            MainWork.AllSessionsInfoListView.Items.Refresh();
        }
        protected void UpdateTicketInfo()
        {
            AllTickets = DataWorker.GetAllTickets();
            MainWork.AllTiketsInfoListView.ItemsSource = null;
            MainWork.AllTiketsInfoListView.Items.Clear();
            MainWork.AllTiketsInfoListView.ItemsSource = AllTickets;
            MainWork.AllTiketsInfoListView.Items.Refresh();
        }

        private void UpdateSessionComboBoxInfo()
        {
            AllSessionByFilmId = DataWorker.GetAllSessionByFilmId(sessionFilm.id);
            AddTicketViews.SortSessionComboBox.ItemsSource = null;
            AddTicketViews.SortSessionComboBox.Items.Clear();
            AddTicketViews.SortSessionComboBox.ItemsSource = AllSessionByFilmId;
            AddTicketViews.SortSessionComboBox.Items.Refresh();
        }


        //protected void UpdateDisciplinesInfo()
        //{
        //    AllDisciplines = DataWorker.GetAllDisciplines();
        //    DeleteEditWindow.AllDisciplineInfoListView.ItemsSource = null;
        //    DeleteEditWindow.AllDisciplineInfoListView.Items.Clear();
        //    DeleteEditWindow.AllDisciplineInfoListView.ItemsSource = AllDisciplines;
        //    DeleteEditWindow.AllDisciplineInfoListView.Items.Refresh();
        //}

        public static void ShowMessageToUser(string message)
        {
            MessageWindow newMessageWindow = new MessageWindow(message);
            newMessageWindow.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            newMessageWindow.ShowDialog();

        }
        protected void SetCenterPositionAndOpen(Window window)
        {
            window.Owner = Application.Current.MainWindow;
            window.WindowStartupLocation = WindowStartupLocation.CenterOwner;
            window.ShowDialog();
        }

        private RelayCommand openAddNewFilmWnd;
        public RelayCommand OpenAddNewFilmWnd
        {
            get
            {
                return openAddNewFilmWnd ?? new RelayCommand(obj =>
                {
                    OpenAddFilmWindowMethod();
                }
                );
            }
        }
        private RelayCommand openAddNewHallWnd;
        public RelayCommand OpenAddNewhallWnd
        {
            get
            {
                return openAddNewHallWnd ?? new RelayCommand(obj =>
                {
                    OpenAddHallWindowMethod();
                }
                );
            }
        }
        private RelayCommand openAddNewSessionWnd;
        public RelayCommand OpenAddNewSessionWnd
        {
            get
            {
                return openAddNewSessionWnd ?? new RelayCommand(obj =>
                {
                    OpenAddSessionWindowMethod();
                }
                );
            }
        }
        private RelayCommand openAddNewTicketWnd;
        public RelayCommand OpenAddNewTicketWnd
        {
            get
            {
                return openAddNewTicketWnd ?? new RelayCommand(obj =>
                {
                    OpenAddTicketWindowMethod();
                }
                );
            }
        }
        protected void SetRedBlockControll(Window wnd, string blockName)
        {
            Control block = wnd.FindName(blockName) as Control;
            block.BorderBrush = Brushes.Red;
        }
        private void OpenAddFilmWindowMethod()
        {
            AddFilmVIews newFilmWindow = new AddFilmVIews();
            SetCenterPositionAndOpen(newFilmWindow);
        }

        private void OpenAddHallWindowMethod()
        {
            AddHallViews newHallWindow = new AddHallViews();
            SetCenterPositionAndOpen(newHallWindow);
        }

        private void OpenAddSessionWindowMethod()
        {
            AddSessionViews newSessionWindow = new AddSessionViews();
            SetCenterPositionAndOpen(newSessionWindow);
        }
        private void OpenAddTicketWindowMethod()
        {
            AddTicketViews newTicketWindow = new AddTicketViews();
            SetCenterPositionAndOpen(newTicketWindow);
        }


        protected RelayCommand deleteItem;
        public RelayCommand DeleteItem
        {
            get
            {
                return deleteItem ?? new RelayCommand(obj =>
                {
                    string resultStr = "Ничего не выбрано";
                    //если Fllms
                    if (SelectedTabItem.Name == "FilmTab" && SelectedFilm != null)
                    {
                        resultStr = DataWorker.DeleteFilm(SelectedFilm);
                        UpdateInfoView();
                    }
                    //если hall
                    if (SelectedTabItem.Name == "HallsTab" && SelectedHall != null)
                    {
                        resultStr = DataWorker.DeleteHall(SelectedHall);
                        UpdateInfoView();
                    }
                    //если Session
                    if (SelectedTabItem.Name == "SessionTab" && SelectedSession != null)
                    {

                        resultStr = DataWorker.DeleteSession(SelectedSession);
                        UpdateInfoView();
                    }
                    //если Session
                    if (SelectedTabItem.Name == "TicketTab" && SelectedTicket != null)
                    {

                        resultStr = DataWorker.DeleteTicket(SelectedTicket);
                        UpdateInfoView();
                    }
                    //обновление
                    SetNullValuesToProperties();
                    ShowMessageToUser(resultStr);
                }
                    );
            }
        }

    }
}
