﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using WpfAppCinema.Resources.MVVM.Models;

namespace WpfAppCinema.Resources.MVVM.ViewModels
{
      public class EditFilmVM : DataManageVM
    {
        private RelayCommand editFilm;
        public RelayCommand EditFilm
        {
            get
            {
                return editFilm ?? new RelayCommand(obj =>
                {
                    Window window = obj as Window;
                    string resultStr = "Не выбран Клиент";


                    if (SelectedFilm != null)
                    {

                        resultStr = DataWorker.EditFilm(SelectedFilm, filmName, filmHall);

                        UpdateInfoView();
                        SetNullValuesToProperties();
                        ShowMessageToUser(resultStr);
                        window.Close();


                    }
                    else ShowMessageToUser(resultStr);

                }
                );
            }
        }
    }
}
