﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using WpfAppCinema.Resources.MVVM.Models;

namespace WpfAppCinema.Resources.MVVM.ViewModels
{
      public class EditHallVM : DataManageVM
    {
        private RelayCommand editHall;
        public RelayCommand EditHall
        {
            get
            {
                return editHall ?? new RelayCommand(obj =>
                {
                    Window window = obj as Window;
                    string resultStr = "Не выбран Клиент";


                    if (SelectedHall != null)
                    {

                        resultStr = DataWorker.EditHall(SelectedHall,choiceHall);

                        UpdateInfoView();
                        SetNullValuesToProperties();
                        ShowMessageToUser(resultStr);
                        window.Close();


                    }
                    else ShowMessageToUser(resultStr);

                }
                );
            }
        }
    }
}
