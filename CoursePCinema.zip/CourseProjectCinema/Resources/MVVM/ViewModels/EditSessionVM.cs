﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using WpfAppCinema.Resources.MVVM.Models;

namespace WpfAppCinema.Resources.MVVM.ViewModels
{
     public class EditSessionVM : DataManageVM
    {
        private RelayCommand editSession;
        public RelayCommand EditSession
        {
            get
            {
                return editSession ?? new RelayCommand(obj =>
                {
                    Window window = obj as Window;
                    string resultStr = "Не выбран Клиент";


                    if (SelectedSession != null)
                    {

                        resultStr = DataWorker.EditSession(SelectedSession, FilmNAME, price, date);

                        UpdateInfoView();
                        SetNullValuesToProperties();
                        ShowMessageToUser(resultStr);
                        window.Close();


                    }
                    else ShowMessageToUser(resultStr);

                }
                );
            }
        }
    }
}
