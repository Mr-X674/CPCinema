﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfAppCinema.Resources.MVVM.Views
{
    /// <summary>
    /// Логика взаимодействия для MainWork.xaml
    /// </summary>
    public partial class MainWork : Window
    {
        public static ListView AllFilmsInfoListView;
        public static ListView AllHallsInfoListView;
        public static ListView AllSessionsInfoListView;
        public static ListView AllTiketsInfoListView;
        public MainWork()
        {

            InitializeComponent();
            AllFilmsInfoListView = ViewAllFilm;
            AllHallsInfoListView = ViewAllHalls;
            AllSessionsInfoListView = ViewAllSessions;
            AllTiketsInfoListView = ViewAllTicket;

        }

        private void ViewAllTicket_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
