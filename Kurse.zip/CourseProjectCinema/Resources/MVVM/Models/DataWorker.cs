﻿using System.Collections.Generic;
using System.Linq;
using WpfAppCinema.Resources.MVVM.Models.Data;

namespace WpfAppCinema.Resources.MVVM.Models
{
    public class DataWorker
    {
        #region[Вся таблица]
        public static List<Film> GetAllFilms()
        {
            using (ApplicationContext db = new ApplicationContext())
            {
                var result = db.Films.ToList();
                return result;
            }
        }

        public static List<Hall> GetAllHalls()
        {
            using (ApplicationContext db = new ApplicationContext())
            {
                var result = db.Halls.ToList();
                return result;
            }
        }

        public static List<Session> GetAllSessions()
        {
            using (ApplicationContext db = new ApplicationContext())
            {
                var result = db.Sessions.ToList();
                return result;
            }
        }

        public static List<Ticket> GetAllTickets()
        {
            using (ApplicationContext db = new ApplicationContext())
            {
                var result = db.Tickets.ToList();
                return result;
            }

        }
        #endregion

        #region[Список по Id]
        public static List<Session> GetAllSessionByFilmId(int id)
        {
            using (ApplicationContext db = new ApplicationContext())
            {
                List<Session> students = (from Session in GetAllSessions() where Session.FilmId == id select Session).ToList();
                return students;
            }
        }

        public static List<Hall> GetAllHallsById(int id)
        {
            using (ApplicationContext db = new ApplicationContext())
            {
                List<Hall> cp = (from Hall in GetAllHalls() where Hall.Id == id select Hall).ToList();
                return cp;
            }
        }

        public static List<Session> GetAllSessionsById(int id)
        {
            using (ApplicationContext db = new ApplicationContext())
            {
                List<Session> cp = (from Session in GetAllSessions() where Session.Id == id select Session).ToList();
                return cp;
            }
        }

        public static List<Ticket> GetAllTicketsById(int id)
        {
            using (ApplicationContext db = new ApplicationContext())
            {
                List<Ticket> cp = (from Ticket in GetAllTickets() where Ticket.Id == id select Ticket).ToList();
                return cp;
            }
        }
        #endregion

        #region[По Id]
        public static Film GetFilmById(int id)
        {
            using (ApplicationContext db = new ApplicationContext())
            {
                Film pos = db.Films.FirstOrDefault(p => p.Id == id);
                return pos;
            }
        }

        public static Hall GetHallById(int id)
        {
            using (ApplicationContext db = new ApplicationContext())
            {
                Hall pos = db.Halls.FirstOrDefault(p => p.Id == id);
                return pos;
            }
        }

        public static Session GetSessionById(int id)
        {
            using (ApplicationContext db = new ApplicationContext())
            {
                Session pos = db.Sessions.FirstOrDefault(p => p.Id == id);
                return pos;
            }
        }

        public static Ticket GetTicketById(int id)
        {
            using (ApplicationContext db = new ApplicationContext())
            {
                Ticket pos = db.Tickets.FirstOrDefault(p => p.Id == id);
                return pos;
            }
        }
        #endregion

        #region[Film]
        public static string CreateFilm(string filmName)
        {
            string result = "Уже существует";
            using (ApplicationContext db = new ApplicationContext())
            {
                //проверяем сущесвует ли фильм
                bool checkIsExist = db.Films.Any(el => el.FilmName == filmName);
                if (!checkIsExist)
                {
                    Film newFilms = new Film
                    {
                        FilmName = filmName
                    };
                    db.Films.Add(newFilms);
                    db.SaveChanges();
                    result = "Фильм добавлен!";
                }
                return result;
            }
        }

        public static string EditFilm(Film oldFilm, string filmName)
        {
            string result = "Такого Резервирование не существует";
            using (ApplicationContext db = new ApplicationContext())
            {
                Film film = db.Films.FirstOrDefault(d => d.Id == oldFilm.Id);
                film.FilmName = filmName;

                db.SaveChanges();
                result = "Сделано! filmName " + film.FilmName + " изменено";
            }
            return result;
        }

        public static string DeleteFilm(Film films)
        {
            string result = "Такой Film не существует";
            using (ApplicationContext db = new ApplicationContext())
            {
                db.Films.Remove(films);
                db.SaveChanges();
                result = "Сделано! " + films.FilmName + " Удалена";
            }
            return result;
        }
        #endregion

        #region[Hall]
        public static string CreateHall(string choiceHall)
        {
            string result = "Уже существует";
            using (ApplicationContext db = new ApplicationContext())
            {
                //проверяем сущесвует ли 
                bool checkIsExist = db.Halls.Any(el => el.ChoiceHall == choiceHall);
                if (!checkIsExist)
                {
                    Hall newHalls = new Hall
                    {
                        ChoiceHall = choiceHall

                    };
                    db.Halls.Add(newHalls);
                    db.SaveChanges();
                    result = " добавлен!";
                }
                return result;
            }
        }

        public static string EditHall(Hall oldHall, string choiceHall)
        {
            string result = "Такого Резервирование не существует";
            using (ApplicationContext db = new ApplicationContext())
            {
                Hall halls = db.Halls.FirstOrDefault(d => d.Id == oldHall.Id);
                halls.ChoiceHall = choiceHall;


                db.SaveChanges();
                result = "Сделано! choiceHall " + halls.ChoiceHall + " изменено";
            }
            return result;
        }

        public static string DeleteHall(Hall halls)
        {
            string result = "Такой Film не существует";
            using (ApplicationContext db = new ApplicationContext())
            {
                db.Halls.Remove(halls);
                db.SaveChanges();
                result = "Сделано! " + halls.ChoiceHall + " Удалена";
            }
            return result;
        }
        #endregion

        #region[Session]
        public static string CreateSession(Film film, int price, string date)
        {
            string result = "Уже существует";
            using (ApplicationContext db = new ApplicationContext())
            {
                //проверяем сущесвует ли 
                bool checkIsExist = db.Sessions.Any(el => el.Price == price &&
                    el.Date == date && el.FilmId == film.Id);
                if (!checkIsExist)
                {
                    Session newSession = new Session
                    {
                        FilmId = film.Id,
                        Price = price,
                        Date = date

                    };
                    db.Sessions.Add(newSession);
                    db.SaveChanges();
                    result = " добавлен!";
                }
                return result;
            }
        }

        public static string EditSession(Session oldSession, Film filmName, int price, string date)
        {
            string result = "Такого Резервирование не существует";
            using (ApplicationContext db = new ApplicationContext())
            {
                Session session = db.Sessions.FirstOrDefault(d => d.Id == oldSession.Id);
                session.FilmId = filmName.Id;
                session.Price = price;
                session.Date = date;


                db.SaveChanges();
                result = "Сделано! choiceHall " + session.Price + " изменено";
            }
            return result;
        }

        public static string DeleteSession(Session sessions)
        {
            string result = "Такой Film не существует";
            using (ApplicationContext db = new ApplicationContext())
            {
                db.Sessions.Remove(sessions);
                db.SaveChanges();
                result = "Сделано! " + sessions.Price + " Удалена";
            }
            return result;
        }
        #endregion

        #region[Ticket]
        public static string CreateTicket(Session session, Hall hall,
            int amountRows, int amountPlace)
        {
            string result = "Уже существует";
            using (ApplicationContext db = new ApplicationContext())
            {
                //проверяем сущесвует ли 
                bool checkIsExist = db.Tickets.Any(el => el.AmountRows == amountRows &&
                    el.HallId == hall.Id && el.AmountPlace == amountPlace && el.SessionId == session.Id);
                if (!checkIsExist)
                {
                    Ticket newtickets = new Ticket
                    {
                        SessionId = session.Id,
                        AmountPlace = amountPlace,
                        AmountRows = amountRows,
                        HallId = hall.Id,
                    };
                    db.Tickets.Add(newtickets);
                    db.SaveChanges();
                    result = " добавлен!";
                }
                return result;
            }
        }

        public static string EditTicket(Ticket oldTicket, Film film, Session session, Hall hall, int row, int place)
        {
            string result = "Такого Резервирование не существует";
            using (ApplicationContext db = new ApplicationContext())
            {
                Ticket ticket = db.Tickets.FirstOrDefault(d => d.Id == oldTicket.Id);
                ticket.Session.FilmId = film.Id;
                ticket.Session.Date = session.Date;
                ticket.Session.FilmId = hall.Id;
                ticket.AmountRows = row;
                ticket.AmountPlace = place;

                db.SaveChanges();
                result = "Сделано! choiceHall " + ticket.AmountRows + " изменено";
            }
            return result;
        }

        public static string DeleteTicket(Ticket tickets)
        {
            string result = "Такой Film не существует";
            using (ApplicationContext db = new ApplicationContext())
            {
                db.Tickets.Remove(tickets);
                db.SaveChanges();
                result = "Сделано! " + tickets.AmountPlace + tickets.AmountRows + " Удалена";
            }
            return result;
        }
        #endregion
    }
}
