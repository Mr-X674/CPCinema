﻿namespace WpfAppCinema.Resources.MVVM.Models
{
    public class Film
    {
        public int Id { get; set; }
        public string FilmName { get; set; }
    }
}
