﻿namespace WpfAppCinema.Resources.MVVM.Models
{
    public class Hall
    {
        public int Id { get; set; }
        public string ChoiceHall { get; set; }
    }
}
