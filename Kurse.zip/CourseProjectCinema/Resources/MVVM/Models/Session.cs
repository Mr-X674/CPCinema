﻿using System.ComponentModel.DataAnnotations.Schema;

namespace WpfAppCinema.Resources.MVVM.Models
{
    public class Session
    {
        public int Id { get; set; }
        public int Price { get; set; }
        public string Date { get; set; }
        public int FilmId { get; set; }
        public virtual Film Film { get; set; }

        [NotMapped]
        public Film SessionFilm
        {
            get
            {
                return DataWorker.GetFilmById((int)FilmId);
            }
        }
    }
}
