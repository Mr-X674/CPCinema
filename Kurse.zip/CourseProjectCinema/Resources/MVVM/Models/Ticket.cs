﻿using System.ComponentModel.DataAnnotations.Schema;

namespace WpfAppCinema.Resources.MVVM.Models
{
    public class Ticket
    {
        public int Id { get; set; }
        public int SessionId { get; set; }
        public Session Session { get; set; }
        public int HallId { get; set; }
        public Hall Hall { get; set; }
        public int AmountRows { get; set; }
        public int AmountPlace { get; set; }

        [NotMapped]
        public Session TicketSession
        {
            get
            {
                return DataWorker.GetSessionById((int)SessionId);
            }
        }

        [NotMapped]
        public Hall TicketHall
        {
            get
            {
                return DataWorker.GetHallById((int)HallId);
            }
        }
    }
}
