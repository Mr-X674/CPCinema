﻿using System.Windows;
using WpfAppCinema.Resources.MVVM.Models;

namespace WpfAppCinema.Resources.MVVM.ViewModels
{
    public class AddFilmVM : DataManageVM
    {
        public static string FilmName { get; set; }
        public RelayCommand AddNewFilm
        {
            get
            {
                return null ?? new RelayCommand(obj =>
                {
                    Window window = obj as Window;
                    if (FilmName == null || FilmName.Replace(" ", "").Length == 0)
                    {
                        SetRedBlockControll(window, "TextBoxFilmName");
                    }
                    else
                    {
                        var result = DataWorker.CreateFilm(FilmName);
                        ShowMessageToUser(result);
                        UpdateInfoView();
                        FilmName = null;
                        window.Close();
                    }
                });
            }
        }
    }
}
