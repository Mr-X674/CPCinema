﻿using System.Windows;
using WpfAppCinema.Resources.MVVM.Models;

namespace WpfAppCinema.Resources.MVVM.ViewModels
{
    public class AddHallVM : DataManageVM
    {
        public static string ChoiceHall { get; set; }
        public RelayCommand AddNewHall
        {
            get
            {
                return null ?? new RelayCommand(obj =>
                {
                    Window window = obj as Window;
                    if (ChoiceHall == null)
                    {
                        SetRedBlockControll(window, "TextBoxChoiceHall");
                    }
                    else
                    {
                        var result = DataWorker.CreateHall(ChoiceHall);
                        ShowMessageToUser(result);
                        ChoiceHall = null;
                        window.Close();
                    }
                });
            }
        }
    }
}
