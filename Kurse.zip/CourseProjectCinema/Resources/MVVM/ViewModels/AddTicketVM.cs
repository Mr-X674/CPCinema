﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using WpfAppCinema.Resources.MVVM.Models;

namespace WpfAppCinema.Resources.MVVM.ViewModels
{
    public class AddTicketVM : DataManageVM
    {


        #region COMMANDS TO ADD
        public RelayCommand AddNewTicket
        {
            get
            {
                return null ?? new RelayCommand(obj =>
                {
                    Window wnd = obj as Window;
                    string resultStr = "";
                    if (SelectedFilm == null)
                    {
                        MessageBox.Show("Ошибка выбора фильма");
                    }
                    else if (SelectedSession == null)
                    {
                        MessageBox.Show("Ошибка выбора сессии");
                    }
                    else if (TicketHall == null)
                    {
                        MessageBox.Show("Ошибка выбора сессии");
                    }
                    else if (amountRows == null)
                    {
                        MessageBox.Show("Ошибка выбора ряда");
                    }
                    else if (amountPlace == null)
                    {
                        MessageBox.Show("Ошибка выбора столба");
                    }
                    else
                    {
                        //resultStr = DataWorker.CreateTicket(SelectedFilm, TicketHall, amountRows, amountPlace);
                        UpdateInfoView();
                        SetNullValuesToProperties();
                        wnd.Close();
                    }
                }
                );
            }
        }
        #endregion


    }
}
