﻿using System.Windows;
using WpfAppCinema.Resources.MVVM.Models;

namespace WpfAppCinema.Resources.MVVM.ViewModels
{
    public class EditFilmVM : DataManageVM
    {
        public static string FilmName { get; set; }
        public static Film SelectedFilm { get; set; }

        public EditFilmVM(Film selectedFilm)
        {
            SelectedFilm = selectedFilm;
            FilmName = SelectedFilm.FilmName;
        }

        public RelayCommand EditFilm
        {
            get
            {
                return null ?? new RelayCommand(obj =>
                {
                    Window window = obj as Window;
                    string result = "Не выбран фильм";
                    if (SelectedFilm != null)
                    {
                        if (FilmName == null || FilmName.Replace(" ", "").Length == 0)
                        {
                            SetRedBlockControll(window, "TextBoxFilmName");
                        }
                        else
                        {
                            result = DataWorker.EditFilm(SelectedFilm, FilmName);
                            ShowMessageToUser(result);
                            UpdateInfoView();
                            FilmName = null;
                            SelectedFilm = null;
                            window.Close();
                        }
                    }
                    else ShowMessageToUser(result);
                });
            }
        }
    }
}
