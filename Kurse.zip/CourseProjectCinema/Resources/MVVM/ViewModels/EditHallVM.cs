﻿using System.Windows;
using WpfAppCinema.Resources.MVVM.Models;

namespace WpfAppCinema.Resources.MVVM.ViewModels
{
    public class EditHallVM : DataManageVM
    {
        public static string ChoiceHall { get; set; }   
        public static Hall SelectedHall { get; set; }

        public EditHallVM(Hall selectedHall)
        {
            SelectedHall = selectedHall;
        }

        public RelayCommand EditHall
        {
            get
            {
                return null ?? new RelayCommand(obj =>
                {
                    Window window = obj as Window;
                    string result = "Не выбран зал";
                    if (SelectedHall != null)
                    {
                        if (ChoiceHall == null)
                        {
                            SetRedBlockControll(window, "TextBoxChoiceHall");
                        }
                        else
                        {
                            result = DataWorker.EditHall(SelectedHall, ChoiceHall);
                            ShowMessageToUser(result);
                            ChoiceHall = null;
                            SelectedHall = null;
                            window.Close();
                        }
                    }
                    else ShowMessageToUser(result);
                });
            }
        }
    }
}
