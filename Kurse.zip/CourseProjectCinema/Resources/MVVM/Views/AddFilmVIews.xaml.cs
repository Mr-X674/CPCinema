﻿using System.Windows;

namespace WpfAppCinema.Resources.MVVM.Views
{
    /// <summary>
    /// Логика взаимодействия для AddFilmVIews.xaml
    /// </summary>
    public partial class AddFilmVIews : Window
    {
        public AddFilmVIews()
        {
            InitializeComponent();
        }
    }
}
