﻿using System.Windows;

namespace WpfAppCinema.Resources.MVVM.Views
{
    /// <summary>
    /// Логика взаимодействия для AddHallViews.xaml
    /// </summary>
    public partial class AddHallViews : Window
    {
        public AddHallViews()
        {
            InitializeComponent();
        }
    }
}
