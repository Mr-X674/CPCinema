﻿using System.Windows;
using WpfAppCinema.Resources.MVVM.Models;
using WpfAppCinema.Resources.MVVM.ViewModels;

namespace WpfAppCinema.Resources.MVVM.Views
{
    /// <summary>
    /// Логика взаимодействия для EditFilmViews.xaml
    /// </summary>
    public partial class EditFilmViews : Window
    {
        public EditFilmViews(Film selectedFilm)
        {
            InitializeComponent();
            DataContext = new EditFilmVM(selectedFilm);
        }
    }
}
