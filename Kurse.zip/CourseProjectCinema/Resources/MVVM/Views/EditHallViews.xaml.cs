﻿using System.Windows;
using WpfAppCinema.Resources.MVVM.Models;
using WpfAppCinema.Resources.MVVM.ViewModels;

namespace WpfAppCinema.Resources.MVVM.Views
{
    /// <summary>
    /// Логика взаимодействия для EditHallViews.xaml
    /// </summary>
    public partial class EditHallViews : Window
    {
        public EditHallViews(Hall selectedHall)
        {
            InitializeComponent();
            DataContext = new EditHallVM(selectedHall);
        }
    }
}
